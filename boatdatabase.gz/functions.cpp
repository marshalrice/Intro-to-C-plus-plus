/*******************************************************************************
  Marshal Rice
  mrice4@clemson.edu
  CPSC1020-010
  Cathy Kittelstad
*******************************************************************************/

#include "functions.h"
using namespace std;

// This function prints the menu for the entire program
int printMenu( ){
  int input;
  cout << "*******************************************************************";
  cout << endl;
  cout << "| Menu:                                                           |";
  cout << endl;
  cout << "| 1. load inventory of watercraft from file                       |";
  cout << std::endl;
  cout << "| 2. add additional watercraft to front of list                   |";
  cout << std::endl;
  cout << "| 3. add additional watercraft to end of list                     |";
  cout << std::endl;
  cout << "| 4. number of watercraft in inventory                            |";
  cout << std::endl;
  cout << "| 5. print inventory of watercraft                                |";
  cout << std::endl;
  cout << "| 6. print specs of chosen watercraft                             |";
  cout << std::endl;
  cout << "| 7. delete chosen watercraft                                     |";
  cout << std::endl;
  cout << "| 8. search watercraft by type                                    |";
  cout << std::endl;
  cout << "| 9. search watercraft by motor type                              |";
  cout << std::endl;
  cout << "|10. sort watercraft by price                                     |";
  cout << std::endl;
  cout << "|11. total asset value in inventory                               |";
  cout << std::endl;
  cout << "|12. quit program                                                 |";
  cout << std::endl;
  cout << "*******************************************************************";
  cout << std::endl;
  cout << std::endl;
  cout << " - - > ";
  std::cin >> input;
  return input;
}

// This function gets all the total prices and sums them up and prints it out
// to the terminal.
void TAV( vector<watercraft *> inventory ){
  double TAV = 0;
  // This for loop goes through each watercraft, gets the total price, and
  // sums them all up in a variable TAV.
  for (auto i: inventory){
    TAV += i->getTPrice();
  }
  cout << "The total asset value in the Watercraft Database is ";
  cout << fixed << setprecision(2) << TAV << "." << std::endl;
}

// This function prints the inventory, asks the user for input to specify
// which watercraft specs they want printed, and prints that watercraft's specs
void printSpecs( vector<watercraft *> inventory ){
  int size = 0;
  int input = 0;

  // This for loop prints all the watercrafts located in inventory vector
  for (auto i : inventory){
    i->printWatercraft(size);
    ++size;
  }
  cout << std::endl << std::endl;
  cout << "Enter the # of watercraft to look up specs:" << std::endl;
  cout << "- - > ";
  cin >> input;

  // This switch statement prints the desire print statement based on provided
  // input.
  switch(size){
    case 0:
      cout << "no motor" << std::endl;
      break;
    case 1:
      cout << "out-board motor" << std::endl;
      break;
    case 2:
      cout << "in-board motor" << std::endl;
      break;
  }
}

// This function does what it say it will in the prototype. It will delete a
// desired watercraft that will be specified from the user.
void deleteWatercraft( vector<watercraft *> &inventory ){
  int size = 0;
  int input;


  cout << endl << endl << "    Printed Inventory List: " << endl << endl;

  // This for loop prints all watercraft in inventory vector
  for (auto i : inventory){
    i->printWatercraft(size);
    ++size;
  }
  cout << endl << endl;
  size = 0;
  cout << "Select which watercraft you would like to delete: ";
  cin  >> input;
  // This erases the actual watercraft from the vector
  inventory.erase(inventory.begin() + (input - 1));
  cout << endl << endl;
  cout << "Watercraft " << input << " has been deleted." << endl << endl;
  }

// This function traverses through the inventory vector and prints specific
// watercrafts based on a specific type that was provided from input.
void searchByType( vector<watercraft *> inventory ){
  string type;


  // these print statements create the prompt for user to search by type.
  cout << endl;
  cout << endl;
  cout << "Type of watercraft to search for:" << endl;
  cout << "1. pontoon" << endl;
  cout << "2. fishing" << endl;
  cout << "3. sport boat" << endl;
  cout << "4. kayak" << endl;
  cout << "5. canoe" << endl;
  cout << "6. sailboat" << endl << endl;
  cout << "- - > ";
  cin >> type;  // This actually gets the input from user.
  cout << endl << endl;
  int index = 0;

  // This for loop checks each watercraft to see if each watercraft's type is
  // identical to the one provided from input. If so, then the for loop prints
  // that watercraft data through its own print Watercraft method.
  for (auto i : inventory){
    if (type == i->getType()){
      i->printWatercraft(index);
      ++index;
    }
  }
}


// This function prints all of the watercrafts that have the same motor as the
// one provided from input.
void searchByMotorType( vector<watercraft *> inventory ){
  int propulsion;

  cout << endl;
  cout << endl;

  // This prompts user for motor type
  cout << "Motor type to search for:" << endl;
  cout << "1. None" << endl;
  cout << "2. Out board" << endl;
  cout << "3. In board" << endl << endl;
  cout << "- - > ";
  cin >> propulsion; // This actually gets the motor type
  propulsion = propulsion - 1;
  cout << endl << endl;
  int index = 0;

  // This traverses through inventory to find watercrafts with said motor type
  // and it prints said watercrafts to the terminal through their own print
  // methods.
  for (auto i : inventory){
    if (propulsion == i->getPropulsion()){
      i->printWatercraft(index);
      ++index;
    }
  }
  cout << endl << endl;
}


// This function creates a new vector that is sorted by inventory's prices, and
// prints each watercraft in the new inventory vector in order from lowest price
// to highest price.
void printByPrice( vector<watercraft *> inventory ){
  int index = 0;

  // This creates the new vector
  vector<watercraft*> tempInventory;
  tempInventory = inventory; // This sets up new vector for organization
  // This actually sorts the new vector.
  sort(tempInventory.begin(), tempInventory.end(), comparePrice); //

  // This for loop prints all watercrafts in new vector inventory.
  for (auto i : tempInventory){
    i->printWatercraft(index);
    ++index;
  }

  // This disposes of the new vector elements properly
  cout << endl << endl;
  for (auto i : tempInventory){
    delete i;
  }

  tempInventory.clear(); // This actuall disposes of the vector itself.

}


// This function creates a new watercraft from input and returns the new
// watercraft that was created.
watercraft* setWatercraft(){

  // Declarations need for new watercraft input
  string type;
  int checkExtras;
  string make;
  string model;
  int propulsion;
  string engine;
  int hp;
  string color;
  int length;
  double base_price;
  double total_price;
  double bimini;
  double towbar;
  double stereo;
  double table;
  double gps;
  double anchor;
  double paddles;

  // All of these print and input statements gets all the data for the new
  // watercraft.
  cout << "Enter the watercraft's type: ";
  cin  >> type;
  cout << endl;
  cout << "Enter the watercraft's make: ";
  cin  >> make;
  cout << endl;
  cout << "Enter the watercraft's model: ";
  cin  >> model;
  cout << endl;
  cout << "Enter the watercraft's engine: ";
  cin  >> engine;
  cout << endl;
  cout << "Enter the watercraft's propulsion:" << endl << endl;
  cout << "\tEnter the following numbers:";
  cout << "\n\t\t1. none\n\t\t2. In board\n\t\t3. Out board\n\tEnter here: ";
  cin  >> propulsion;
  propulsion = propulsion - 1;
  cout << endl;
  cout << "Enter the watercraft's horsepower: ";
  cin  >> hp;
  cout << endl;
  cout << "Enter the watercraft's color: ";
  cin  >> color;
  cout << endl;
  cout << "Enter the watercraft's length: ";
  cin  >> length;
  cout << endl;
  cout << "Enter the watercraft's base price: ";
  cin  >> base_price;
  cout << endl;
  cout << "Enter the watercraft's total price: ";
  cin  >> total_price;
  cout << endl;
  cout << "Will there be any accessories? (1 for yes and 0 for no) - - > ";
  cin  >> checkExtras;
  cout << endl;
  if (checkExtras == 1){
    cout << "Enter the bimini price: ";
    cin  >> bimini;
    cout << endl;
    cout << "Enter the towbar price: ";
    cin  >> towbar;
    cout << endl;
    cout << "Enter the stereo price: ";
    cin  >> stereo;
    cout << endl;
    cout << "Enter the table price: ";
    cin  >> table;
    cout << endl;
    cout << "Enter the GPS price: ";
    cin  >> gps;
    cout << endl;
    cout << "Enter the anchor price: ";
    cin  >> anchor;
    cout << endl;
    cout << "Enter the paddles price: ";
    cin  >> paddles;
    cout << endl;
  }
  else{
    // This is the default if no extras were provided.
    bimini = 0;
    towbar = 0;
    stereo = 0;
    table = 0;
    gps = 0;
    anchor = 0;
    paddles = 0;
  }

  // This actually creates the new watercraft from the given input through
  // a parameterized constructor and through memory allocation.
  watercraft* object = new watercraft(type, make, model, propulsion, engine, hp,
    color, length, base_price, total_price, bimini, towbar, stereo, table, gps,
    anchor, paddles );
  return object;
}


// This boolean function is solely used in the printByPrice function. It is
// used to sort each watercraft in the new temprorary vector by their watercraft
// prices. Once one price is determined less than the other, true or false is
// returned.
bool comparePrice(watercraft* price1 , watercraft* price2){
  if (price1->getTPrice() < price2->getTPrice()){
    return true;
  }
  else {
    return false;
  }
}

// END OF FUNCTIONS.CPP FILE
