/*******************************************************************************
  Marshal Rice
  mrice4@clemson.edu
  CPSC1020-010
  Cathy Kittelstad
*******************************************************************************/

#include "watercraft.h"

// This creates the default watercraft constructor and initializes all private
// members of watercraft to 0 or whitespace for strings.
watercraft::watercraft(){
  type = " ";
  make = " ";
  model = " ";
  propulsion = 0;
  engine = " ";
  hp = 0;
  color = " ";
  length = 0;
  base_price = 0.0;
  total_price = 0.0;
  extras.set_bimini(0);
  extras.set_towbar(0);
  extras.set_stereo(0);
  extras.set_table(0);
  extras.set_gps(0);
  extras.set_anchor(0);
  extras.set_paddles(0);
}

// This constructor constructs a watercraft that is scanned in from input file.
watercraft::watercraft( ifstream &inFile ){
  // This checks to see if the input text file has already been used.
  if(inFile.eof()){
    cout << "The file has already ended.";
    return;
  }

  // If not already been used, this starts the declarations needed for the
  // scanning process.
  string inLine, inProp, inHp, inLength;
  string inBimini, inTowbar, inStero, inTable, inGPS, inAnchor, inPaddles;
  string inBase, inTotal;
  stringstream inCopy;
  char delimeter(',');

  // Gets each line from input file, stores it in a string stream, and uses
  // getline function again to get each piece of data up until each comma is
  // encountered. After that, the information is stored in the private data
  // members of watercraft class.
  if(getline(inFile,inLine)){
    inCopy.str(inLine);
    getline(inCopy, type, delimeter);
    getline(inCopy, make, delimeter);
    getline(inCopy, model, delimeter);
    getline(inCopy, inProp, delimeter);
    propulsion = stoi(inProp);
    getline(inCopy, engine, delimeter);
    getline(inCopy, inHp, delimeter);
    hp = stoi(inHp);
    getline(inCopy, color, delimeter);
    getline(inCopy, inLength, delimeter);
    length = stoi(inLength);
    getline(inCopy, inBase, delimeter);
    base_price = stod(inBase);
    getline(inCopy, inTotal, delimeter);
    total_price = stod(inTotal);
    getline(inCopy, inBimini, delimeter);
    extras.set_bimini(stod(inBimini));
    getline(inCopy, inTowbar, delimeter);
    extras.set_towbar(stod(inTowbar));
    getline(inCopy, inStero, delimeter);
    extras.set_stereo(stod(inStero));
    getline(inCopy, inTable, delimeter);
    extras.set_table(stod(inTable));
    getline(inCopy, inGPS, delimeter);
    extras.set_gps(stod(inGPS));
    getline(inCopy, inAnchor, delimeter);
    extras.set_anchor(stod(inAnchor));
    getline(inCopy, inPaddles, delimeter);
    extras.set_paddles(stod(inPaddles));
    }
    else{
      return;
    }
  }


// This prints all the information in a watercraft in a specific uniformed way.
  void watercraft::printWatercraft ( int index ){
    cout << fixed << setw(2) << index + 1 << ". " << left << setw(12) << type;
    cout << fixed << left << setw(20) << make;
    cout << fixed << left << setw(22) << model;
    cout << fixed << left << setw(11) << engine;
    cout << fixed << right<< setw(3)  << hp << " hp  ";
    cout << fixed << left << setw(19) << color;
    cout << fixed << setw(3) << right << length   << " ft  $";
    cout << fixed << right<< setw(10) << setprecision(2) << total_price;
    cout << endl;
  }

// This prompts the user to pick a watercraft from the all of the watercrafts
// that are printed, gets the input, finds the desired watercraft, and prints
// all of the information of that specific watercraft.
  void watercraft::printSpecs ( vector<watercraft *> inventory ){
    int size = 0;
    int input;
    int index;
    for (auto i : inventory){
      i->printWatercraft(size);
      ++size;
    }
    cout << endl << endl;
    cout << "Enter the # of watercraft to look up specs:\n - - > ";
    cin >> input;
    index = input - 1;
    inventory[index]->printWatercraft(index);
    cout << "\n\t";
    switch(inventory[index]->getPropulsion()){
      case 0:
        cout << "no motor" << endl;
        break;
      case 1:
        cout << "out-board motor" << endl;
        break;
      case 2:
        cout << "in-board motor" << endl;
        break;
    }
    if (inventory[index]->getBPrice() != 0){
    cout << "\tbase price: $ ";
    cout << fixed << setw(9) << setprecision(2) <<inventory[index]->getBPrice();
    cout << endl << "\t";
    }

    if (inventory[index]->getExtras().get_bimini() != 0){
      cout << "bimini:     $ ";
      cout << setw(9) << setprecision(2);
      cout << inventory[index]->getExtras().get_bimini() << endl << "\t";
    }
    if (inventory[index]->getExtras().get_towbar() != 0){
      cout << "towbar:     $ ";
      cout << setw(9) << setprecision(2);
      cout << inventory[index]->getExtras().get_towbar() << endl << "\t";
    }
    if (inventory[index]->getExtras().get_table() != 0){
      cout << "table:      $ ";
      cout << setw(9) << setprecision(2);
      cout << inventory[index]->getExtras().get_table() << endl << "\t";
    }
    if (inventory[index]->getExtras().get_gps() != 0){
      cout << "gps:        $ ";
      cout << setw(9) << setprecision(2);
      cout << inventory[index]->getExtras().get_gps() << endl << "\t";
    }
    if (inventory[index]->getExtras().get_anchor() != 0){
      cout << "anchor:     $ ";
      cout << setw(9) << setprecision(2);
      cout << inventory[index]->getExtras().get_anchor() << endl << "\t";
    }
    if (inventory[index]->getExtras().get_paddles() != 0){
      cout << "paddles:    $ ";
      cout << setw(9) << setprecision(2);
      cout << inventory[index]->getExtras().get_paddles() << endl << "\t";
    }
    if (inventory[index]->getExtras().get_stereo() != 0){
      cout << "stereo:     $ ";
      cout << setw(9) << setprecision(2);
      cout << inventory[index]->getExtras().get_stereo() << endl << "\t";
    }
    cout << endl;
  }

// END OF WATERCRAFT.CPP FILE
