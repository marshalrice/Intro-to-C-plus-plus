/*******************************************************************************
  Marshal Rice
  mrice4@clemson.edu
  CPSC1020-010
  Cathy Kittelstad

  Program Description: This program replicated a similar program that was made
      previously in the year, but converts all of that code into C++ code. There
      is also more refinement in this code as well. This program essentially
      creates a database system for watercraft users and can add, modify, and
      rearrange different watercrafts through a watercraft vector. All of the
      code's possible functions are specified in the menu that will print every
      time until the user specifies an end to the program.
*******************************************************************************/
#include "accessories.h"
#include "functions.h"
#include "watercraft.h"

// This is where the program begins
int main(int argc, char** argv){ //gets input text file through command line

  // checks to see if only the text file was inputted
  if (argc != 2){
    cout << "The wrong amount of text files were imputted. ";
    cout << "Please enter only one text file." << endl;
  }

  // if text file inputted, then declarative programming starts.
  ifstream waterFile;
  waterFile.open(argv[1]);
  vector<watercraft*> inventory;



  // More declarations
  int input = 0;
  int size = 0;
  int specNum;

  // This is the introductory print statement
  cout << "\n     Welcome to the Watercraft Inventory Database" << endl << endl;

  // This is where the main programming happens. This is a while loop that does
  // not end until the user says so, and keeps printing out the desired output
  // that the user wants.
  while(input != 12){
    input = printMenu(); // Prints the menu and gets desired input each time.
    switch(input){ // This switch statement takes input and picks the desired
      // code that was specified in the Menu.
      case 1:
        // this checks if the input file has already been used
        if (waterFile.eof()){
          cout << "File " << argv[1] << " has already been loaded" << endl;
          cout << endl;
          break;
        }

        // If not used, then the file is read into new watercrafts and read into
        // the inventory vector.
        while(!(waterFile.eof())){
            watercraft* object = new watercraft(waterFile);
            inventory.push_back(object);
        }
        inventory.pop_back(); // Deletes last element because of empty element
        // declared at the end. Only a one time use.
        // This if statement prints if the file has successfully ended
        if (waterFile.eof()){
          cout << "File " << argv[1] << " successfully loaded" << endl << endl;
        }
        break;
      case 2:
        // This creates a new watercraft and puts it at inventory's beginning.
        inventory.insert(inventory.begin(), setWatercraft());
        break;
      case 3:
      // This creates a new watercraft and puts it at inventory's ending.
        inventory.push_back(setWatercraft());
        break;
      case 4:
        // This simply gets the number of watercrafts through an integer that
        // traverses through inventory and adds by 1 per watercraft.

        cout << endl << endl;
        cout << "The number of watercraft in the Watercraft Database is ";
        size = 0;

        // This is the for loop that goes through inventory and increments size
        // per watercraft encountered

        for (auto i : inventory){
          ++size;
        }
        cout << size << ".";
        cout << endl << endl;
        size = 0; // resets size for multiple usage.
        break;
      case 5:
        // This just prints all watercraft in inventory through a for loop.
        cout << endl << endl << "    Printed Inventory List: " << endl << endl;
        for (auto i : inventory){
          i->printWatercraft(size); // This is the for loop that increments size
          ++size;
        }
        cout << endl << endl;
        size = 0;
        break;
      case 6:
        // This prints a specific watercraft and it's extras, which is all
        // provided by input.
        inventory[0]->printSpecs(inventory);
        break;
      case 7:
        // This deletes a desired watercraft that is provided from input.
        deleteWatercraft(inventory);
        break;
      case 8:
      // This prints all of the watercraft types that will be specified from
      // input.
        searchByType(inventory);
        break;
      case 9:
        // This prints all of the motor types that will be specified from input.
        searchByMotorType(inventory);
        break;
      case 10:
        // This calls printByPrice and does what it say it will do. It prints
        // the inventory by its total_price. Lowest to highest price of course.
        printByPrice(inventory);
        break;
      case 11:
        // This calls the Total Average Value function to get the sum of all the
        // total_prices in each watercraft that is in inventory.
        cout << endl << endl;
        TAV(inventory);
        cout << endl << endl;
        break;
      case 12:
        // This prints a Goodbye message and deletes all that was created with
        // memory allocation.
        cout << "\n\nThank you for using the Watercraft Database. Goodbye!\n\n";
        for (auto i : inventory){
          delete i;
        }
        inventory.clear();
        return 0;
        break;
      default:
        // This default ends the program with an error message and deletes
        // inventory and its watercraft members properly.
        cout << "\n\nSorry that wasn't an appropriate response. Please print ";
        cout << "a number between 1 and 12. Thank you.\n\n";
        for (auto i : inventory){
          delete i;
        }
        inventory.clear();
        input = 12;
        break;
    }
  }
  return (0);
}

// END OF MAIN PROGRAM
