/*******************************************************************************
  Marshal Rice
  mrice4@clemson.edu
  CPSC1020-010
  Cathy Kittelstad
*******************************************************************************/

#include "accessories.h"

// This creates the default constructor for accessories.
accessories::accessories( ) : bimini(0), towbar(0), stereo(0), table(0), gps(0),
  anchor(0), paddles(0) { ; }

// END OF ACCESSORIES.CPP FILE
